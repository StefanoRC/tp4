function indiceMasaMuscular() {
    altura = parseFloat(document.getElementById("altura").value);
    peso = parseFloat(document.getElementById("peso").value);
   
    
    if (altura == 0 || peso == 0) {
        resultado = "Ingrese un valor correcto";
    }


    alturaM = altura / 100;
    indice = peso / (alturaM * alturaM);
    indice = indice.toFixed(2);

    switch (true) {
        case indice <= 15.99:
            resultado = indice + " Delgadez Severra";
            break

        case indice >= 16 && indice <= 18.49:
            resultado = indice + " Delgadez";
            break

        case indice >= 18.50 && indice <= 24.99:
            resultado = indice + " Peso Normal";
            break

        case indice >= 25 && indice <= 29.99:
            resultado = indice + " Sobrepeso";
            break

        case indice >= 30 && indice <= 34.99:
            resultado = indice + " Obesidad Moderada";
            break

        case indice >= 35 && indice <= 39.99:
            resultado = indice + " Obesidad Severa";
            break

        case indice >= 40:
            resultado = " Obesidad Morbida";
            break

    }
    
    document.getElementById("resultado").innerText=resultado

}


